import { IThread } from "../types";
export const chatActions = {
	START_CHAT: "START_CHAT",
	BACK: "BACK",
	VIEW_THREAD: "VIEW_THREAD",
	CLOSE_CHAT_APP: "CLOSE_CHAT_APP",
	OPEN_CHAT_APP: "OPEN_CHAT_APP",
} as const;
