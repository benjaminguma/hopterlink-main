export const COLLECTION_NAMES = {
	THREADS: "threads",
	MESSAGES: "messages",
	CHAT_PARTICIPANTS: "chat-participant",
};
